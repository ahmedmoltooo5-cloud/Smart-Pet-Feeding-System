import React, { createContext, useContext, useState, useEffect } from "react";

interface Pet {
  name: string;
  details: string;
  ownerPhone: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  currentPet: Pet | null;
  login: (petName: string, password: string) => boolean;
  signup: (petName: string, petDetails: string, ownerPhone: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPet, setCurrentPet] = useState<Pet | null>(null);

  useEffect(() => {
    const savedAuth = localStorage.getItem("petAuth");
    if (savedAuth) {
      const { pet } = JSON.parse(savedAuth);
      setCurrentPet(pet);
      setIsAuthenticated(true);
    }
  }, []);

  const login = (petName: string, password: string) => {
    const storedPets = localStorage.getItem("petUsers");
    if (storedPets) {
      const pets = JSON.parse(storedPets);
      const pet = pets.find(
        (p: any) => p.name === petName && p.password === password
      );
      if (pet) {
        setCurrentPet({ name: pet.name, details: pet.details, ownerPhone: pet.ownerPhone });
        setIsAuthenticated(true);
        localStorage.setItem("petAuth", JSON.stringify({ pet: { name: pet.name, details: pet.details, ownerPhone: pet.ownerPhone } }));
        return true;
      }
    }
    return false;
  };

  const signup = (petName: string, petDetails: string, ownerPhone: string, password: string) => {
    const storedPets = localStorage.getItem("petUsers");
    const pets = storedPets ? JSON.parse(storedPets) : [];

    if (pets.find((p: any) => p.name === petName)) {
      return false;
    }

    pets.push({ name: petName, details: petDetails, ownerPhone, password });
    localStorage.setItem("petUsers", JSON.stringify(pets));

    const newPet = { name: petName, details: petDetails, ownerPhone };
    setCurrentPet(newPet);
    setIsAuthenticated(true);
    localStorage.setItem("petAuth", JSON.stringify({ pet: newPet }));
    return true;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setCurrentPet(null);
    localStorage.removeItem("petAuth");
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, currentPet, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
